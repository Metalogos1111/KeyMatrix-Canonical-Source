# KeyMatrix Evidence-Bound Canonical Source — Candidate 001

This package consolidates separated KeyMatrix reference artifacts and the engineering workspace into one reproducible, hash-indexed source candidate.

## Boundary

`REFERENCE_DECLARATIONS` are provenance/reference material. They do **not** become runtime truth merely because they are present here.

`ENGINEERING_IMPLEMENTATION` is the concrete local implementation snapshot.

`CANONICAL_REGISTRY` is the single reconciliation/index layer for this package.

`PERSISTENT_CANONICAL_SOURCE` is **BLOCKED** until a persistent repository accepts the package and the resulting commit can be independently retrieved and hash-verified.

## Evidence chain

`DISCOVER → IDENTIFY → RECONCILE → BIND → PERSIST → INDEPENDENT RETRIEVE → RUNTIME VERIFY`

Current state stops at `BIND`; `PERSIST` is blocked by lack of repository write authority. No LIVE/VERIFIED/PROVEN/PRODUCTION claim is made.

## Safety

No production Supabase mutations, deployments, authority promotion, NUR issuance, ledger settlement, or mainnet/testnet authorization are implied by this package.

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import shutil
import textwrap
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

APP_DIR = Path(".session_accelerator")
EXPORTS_DIR = APP_DIR / "exports"
MEMORY_FILE = APP_DIR / "memory.json"


def utc_now() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def ensure_dirs() -> None:
    APP_DIR.mkdir(exist_ok=True)
    EXPORTS_DIR.mkdir(exist_ok=True)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def truncate_text(text: str, limit: int = 1200) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


@dataclass
class MemoryItem:
    kind: str
    title: str
    text: str
    created_at: str
    priority: str = "normal"
    tags: Optional[List[str]] = None
    source_path: Optional[str] = None
    sha256: Optional[str] = None


class SessionAccelerator:
    def __init__(self, memory_path: Path = MEMORY_FILE) -> None:
        self.memory_path = memory_path
        ensure_dirs()
        if not self.memory_path.exists():
            self._write({"version": 1, "projects": {}})

    def _read(self) -> Dict[str, Any]:
        with self.memory_path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def _write(self, data: Dict[str, Any]) -> None:
        with self.memory_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def init_project(self, project: str) -> None:
        data = self._read()
        data["projects"].setdefault(
            project,
            {
                "created_at": utc_now(),
                "updated_at": utc_now(),
                "notes": [],
                "decisions": [],
                "tasks": [],
                "files": [],
                "context_summary": "",
                "project_goal": "",
                "constraints": [],
                "preferred_output_style": [],
            },
        )
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)

    def set_goal(self, project: str, goal: str) -> None:
        self.init_project(project)
        data = self._read()
        data["projects"][project]["project_goal"] = goal.strip()
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)

    def add_constraint(self, project: str, constraint: str) -> None:
        self.init_project(project)
        data = self._read()
        data["projects"][project].setdefault("constraints", []).append(constraint.strip())
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)

    def add_style(self, project: str, style: str) -> None:
        self.init_project(project)
        data = self._read()
        data["projects"][project].setdefault("preferred_output_style", []).append(style.strip())
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)

    def add_item(
        self,
        project: str,
        bucket: str,
        title: str,
        text: str,
        priority: str = "normal",
        tags: Optional[List[str]] = None,
    ) -> None:
        if bucket not in {"notes", "decisions", "tasks"}:
            raise ValueError(f"Unsupported bucket: {bucket}")
        self.init_project(project)
        data = self._read()
        item = MemoryItem(
            kind=bucket[:-1],
            title=title.strip(),
            text=text.strip(),
            created_at=utc_now(),
            priority=priority,
            tags=tags or [],
        )
        data["projects"][project][bucket].append(asdict(item))
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)

    def add_file(self, project: str, path_str: str) -> Dict[str, Any]:
        src = Path(path_str).expanduser().resolve()
        if not src.exists() or not src.is_file():
            raise FileNotFoundError(f"File not found: {src}")

        self.init_project(project)
        data = self._read()

        project_dir = APP_DIR / project / "files"
        project_dir.mkdir(parents=True, exist_ok=True)
        dst = project_dir / src.name
        shutil.copy2(src, dst)

        record = {
            "kind": "file",
            "title": src.name,
            "text": f"Attached file for project {project}",
            "created_at": utc_now(),
            "source_path": str(dst),
            "sha256": sha256_file(dst),
            "size_bytes": dst.stat().st_size,
        }
        data["projects"][project]["files"].append(record)
        data["projects"][project]["updated_at"] = utc_now()
        self._write(data)
        return record

    def build_context(self, project: str) -> str:
        data = self._read()
        if project not in data["projects"]:
            raise KeyError(f"Unknown project: {project}")

        p = data["projects"][project]
        notes = p.get("notes", [])[-8:]
        decisions = p.get("decisions", [])[-8:]
        tasks = p.get("tasks", [])[-10:]
        files = p.get("files", [])[-12:]
        goal = p.get("project_goal", "").strip()
        constraints = p.get("constraints", [])
        style = p.get("preferred_output_style", [])

        def render_items(items: List[Dict[str, Any]], header: str) -> str:
            if not items:
                return f"{header}:\n- none"
            lines = [header + ":"]
            for item in items:
                title = item.get("title", "untitled")
                text = truncate_text(item.get("text", ""), 240)
                priority = item.get("priority", "normal")
                lines.append(f"- [{priority}] {title}: {text}")
            return "\n".join(lines)

        file_lines = ["Files:"]
        if files:
            for f in files:
                file_lines.append(
                    f"- {f.get('title')} | sha256={f.get('sha256', '')[:12]}... | path={f.get('source_path')}"
                )
        else:
            file_lines.append("- none")

        parts = [
            f"Project: {project}",
            f"Updated at: {p.get('updated_at', '')}",
            f"Goal: {goal or 'not set'}",
            "Constraints:\n" + ("\n".join(f"- {c}" for c in constraints) if constraints else "- none"),
            "Preferred output style:\n" + ("\n".join(f"- {s}" for s in style) if style else "- none"),
            render_items(decisions, "Key decisions"),
            render_items(tasks, "Active tasks"),
            render_items(notes, "Recent notes"),
            "\n".join(file_lines),
        ]
        summary = "\n\n".join(parts).strip()
        p["context_summary"] = summary
        p["updated_at"] = utc_now()
        self._write(data)
        return summary

    def bootstrap_prompt(self, project: str) -> str:
        data = self._read()
        if project not in data["projects"]:
            raise KeyError(f"Unknown project: {project}")
        p = data["projects"][project]
        summary = p.get("context_summary", "").strip() or self.build_context(project)

        prompt = textwrap.dedent(
            f"""            Ниже — сжатый контекст проекта. Используй его как стартовую память для новой сессии.
            Сначала кратко подтверди, что понял текущее состояние проекта.
            Затем предложи:
            1) 3 главных приоритета,
            2) 3 ближайших шага,
            3) 1 самый сильный риск,
            4) 1 рекомендуемый артефакт для создания прямо сейчас.

            === PROJECT CONTEXT START ===
            {summary}
            === PROJECT CONTEXT END ===

            Правила ответа:
            - не пересказывать всё без необходимости;
            - не терять ключевые решения;
            - учитывать ограничения и стиль;
            - быть конкретным и практичным.
            """
        ).strip()
        return prompt

    def snapshot(self, project: str) -> Dict[str, str]:
        summary = self.build_context(project)
        prompt = self.bootstrap_prompt(project)
        stamp = dt.datetime.utcnow().strftime("%Y%m%d_%H%M%S")

        summary_path = EXPORTS_DIR / f"{project}_context_{stamp}.md"
        prompt_path = EXPORTS_DIR / f"{project}_bootstrap_{stamp}.md"
        json_path = EXPORTS_DIR / f"{project}_snapshot_{stamp}.json"

        summary_path.write_text(summary, encoding="utf-8")
        prompt_path.write_text(prompt, encoding="utf-8")
        json_path.write_text(
            json.dumps(self._read()["projects"][project], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        return {
            "summary_md": str(summary_path),
            "bootstrap_md": str(prompt_path),
            "snapshot_json": str(json_path),
        }

    def show(self, project: str) -> Dict[str, Any]:
        data = self._read()
        if project not in data["projects"]:
            raise KeyError(f"Unknown project: {project}")
        return data["projects"][project]

    def list_projects(self) -> List[str]:
        return sorted(self._read().get("projects", {}).keys())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Accelerate ChatGPT sessions with local project memory.")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="Initialize storage")
    sub.add_parser("projects", help="List projects")

    p_goal = sub.add_parser("set-goal", help="Set project goal")
    p_goal.add_argument("--project", required=True)
    p_goal.add_argument("--goal", required=True)

    p_constraint = sub.add_parser("add-constraint", help="Add project constraint")
    p_constraint.add_argument("--project", required=True)
    p_constraint.add_argument("--text", required=True)

    p_style = sub.add_parser("add-style", help="Add preferred output style")
    p_style.add_argument("--project", required=True)
    p_style.add_argument("--text", required=True)

    for name in ["add-note", "add-decision", "add-task"]:
        p = sub.add_parser(name)
        p.add_argument("--project", required=True)
        p.add_argument("--title", required=True)
        p.add_argument("--text", required=True)
        p.add_argument("--priority", default="normal", choices=["low", "normal", "high", "critical"])
        p.add_argument("--tags", nargs="*", default=[])

    p_file = sub.add_parser("add-file", help="Copy file into project memory")
    p_file.add_argument("--project", required=True)
    p_file.add_argument("--path", required=True)

    p_build = sub.add_parser("build-context", help="Build compact project context")
    p_build.add_argument("--project", required=True)

    p_boot = sub.add_parser("bootstrap", help="Generate bootstrap prompt")
    p_boot.add_argument("--project", required=True)

    p_snap = sub.add_parser("snapshot", help="Export summary + prompt + json")
    p_snap.add_argument("--project", required=True)

    p_show = sub.add_parser("show", help="Show raw project state")
    p_show.add_argument("--project", required=True)

    return parser.parse_args()


def main() -> None:
    args = parse_args()
    app = SessionAccelerator()

    if args.command == "init":
        ensure_dirs()
        print(f"Initialized: {APP_DIR.resolve()}")
        return

    if args.command == "projects":
        print(json.dumps(app.list_projects(), ensure_ascii=False, indent=2))
        return

    if args.command == "set-goal":
        app.set_goal(args.project, args.goal)
        print(f"Goal set for project={args.project}")
        return

    if args.command == "add-constraint":
        app.add_constraint(args.project, args.text)
        print(f"Constraint added to project={args.project}")
        return

    if args.command == "add-style":
        app.add_style(args.project, args.text)
        print(f"Style added to project={args.project}")
        return

    if args.command in {"add-note", "add-decision", "add-task"}:
        bucket = {
            "add-note": "notes",
            "add-decision": "decisions",
            "add-task": "tasks",
        }[args.command]
        app.add_item(
            project=args.project,
            bucket=bucket,
            title=args.title,
            text=args.text,
            priority=args.priority,
            tags=args.tags,
        )
        print(f"{args.command} saved for project={args.project}")
        return

    if args.command == "add-file":
        record = app.add_file(args.project, args.path)
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return

    if args.command == "build-context":
        print(app.build_context(args.project))
        return

    if args.command == "bootstrap":
        print(app.bootstrap_prompt(args.project))
        return

    if args.command == "snapshot":
        print(json.dumps(app.snapshot(args.project), ensure_ascii=False, indent=2))
        return

    if args.command == "show":
        print(json.dumps(app.show(args.project), ensure_ascii=False, indent=2))
        return

    raise RuntimeError(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
